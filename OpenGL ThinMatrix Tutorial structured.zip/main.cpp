
#include "Game.h"

int main()
{

	//StringParser SP;
	//Importer importer;
	//SP.parseOBJ(importer.importTextFile("res/Dragon/dragon.obj"));
	GameLoop GL;
	GL.start();

};